import os
import sys
import numpy as np
import math
from scipy.signal import get_window
import matplotlib.pyplot as plt

sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../software/models/'))
import stft as STFT
import utilFunctions as UF
eps = np.finfo(float).eps


"""
A4-Part-2: Measuring noise in the reconstructed signal using the STFT model 

Write a function that measures the amount of noise introduced during the analysis and synthesis of a 
signal using the STFT model. Use SNR (signal to noise ratio) in dB to quantify the amount of noise. 
Use the stft() function in stft.py to do an analysis followed by a synthesis of the input signal.

A brief description of the SNR computation can be found in the pdf document (A4-STFT.pdf, in Relevant 
Concepts section) in the assignment directory (A4).

Compute two different SNR values for the following cases:

1) SNR1: Over the entire length of the signal
2) SNR2: For the segment of the signal left after discarding M samples from both the start and the 
end, where M is the analysis window length.

The input arguments to the function are the wav file name including the path (inputFile), window 
type (window), window length (M), FFT size (N), and hop size (H). The function should return a python 
tuple of both the SNR values in decibels: (SNR1, SNR2). Both SNR1 and SNR2 are float values. 

EXAMPLE: If you run your code using piano.wav file with 'blackman' window, M = 512, N = 1024 and H = 128, 
the output SNR values should be around: (77.039400951729434, 304.96826393843861).

Note that since SNR2 is quite big (which means that the noise energy is very low), precision differences
on different machines/hardware can cause this number to vary. If SNR2 on your machine is above 250 dB,
your implementation/answer should be correct.
"""
def computeSNR(inputFile, window, M, N, H):
    """
    Input:
            inputFile (string): wav file name including the path 
            window (string): analysis window type (choice of rectangular, triangular, hanning, hamming, 
                    blackman, blackmanharris)
            M (integer): analysis window length (odd positive integer)
            N (integer): fft size (power of two, > M)
            H (integer): hop size for the stft computation
    Output:
            The function should return a python tuple of both the SNR values (SNR1, SNR2)
            SNR1 and SNR2 are floats.
    """
    ## your code here
    def energy(mag):
        e = np.sum((10 ** (mag / 20)) ** 2)
        return e
    
    (fs, x) = UF.wavread(inputFile)
    w = get_window(window, M)
    
    mX, pX = STFT.stftAnal(x, fs, w, N, H)
    y = STFT.stftSynth(mX, pX, M, H)
    n = x - y[:x.size]
    n2 = x[w.size:-w.size] - y[:x.size][w.size:-w.size]
    
    mN, pN = STFT.stftAnal(n, fs, w, N, H)
    mN2, pN2 = STFT.stftAnal(n2, fs, w, N, H)
    
    snr1 = 10 * np.log10(energy(mX) / energy(mN))
    snr2 = 10 * np.log10(energy(mX) / energy(mN2))
        
    return snr1, snr2
